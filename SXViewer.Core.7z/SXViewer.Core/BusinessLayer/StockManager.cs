/*Stock Manager class is used for all Database Operations. This class has four methods, which have the same method signatures 
 as methods in database. Also this class has one constructor.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SXViewer.Core.BusinessLayer;
using SXViewer.Core.DataLayer;

namespace SXViewer.Core.BusinessLayer
{
    public static class StockManager
    {
        public static string Message { get; set; }
        static StockManager()
        {
        }

        //This method call the method in database to check whether stock exists in the database, and returns True or False
        public static bool IsStockExists(string _stockname)
        {
            return StockDatabase.IsStockExists(_stockname);
        }

        //This method calls the method in database to display stocks from Stock Table
        public static IEnumerable<Stock> GetStocks()
        {
            return StockDatabase.GetStocks();
        }

        //This method calls the method in database to insert stock in the stock table
        public static bool SaveStock(string _stockname)
        {
            return StockDatabase.SaveStock(_stockname);
        }

        //This method calls the method in database to delete all the stocks from the stock table
        public static bool DeleteAllStocks()
        {
            return StockDatabase.DeleteAllStocks();
        }

    }
}