/*Stock Database is used to store saved stocks in Market Watch Screen. This database has one single Table with subsequent 
 methods to Fetch, Add and Delete stocks that we are used in Market Watch - Favourite List. */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Mono.Data.Sqlite;
using System.IO;
using SXViewer.Core.BusinessLayer;

namespace SXViewer.Core.DataLayer
{
    public class StockDatabase
    {
        private static string db_file = "stockdata.db3";
        private string stockName = string.Empty;
        private static string sMessage;

        public string StockName
        {
            get { return stockName; }
            set { stockName = value; }
        }

        //This method creates database or returns database
        private static SqliteConnection GetConnection()
        {
            var dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), db_file);
            bool exists = File.Exists(dbPath);

            if (!exists)
                SqliteConnection.CreateFile(dbPath);

            var conn = new SqliteConnection("Data Source=" + dbPath);

            if (!exists)
                CreateDatabase(conn);

            return conn;
        }

        //This method creates Stock table 
        private static void CreateDatabase(SqliteConnection connection)
        {
            var sql = "CREATE TABLE STOCKTABLE (Id INTEGER PRIMARY KEY AUTOINCREMENT, StockName VARCHAR);";

            connection.Open();

            using (var cmd = connection.CreateCommand())
            {
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
            }
            connection.Close();
        }

        //This method displays stocks from Stock Table
        public static IEnumerable<Stock> GetStocks()
        {
            try
            {
                var sql = "SELECT * FROM STOCKTABLE ORDER BY ID;";

                using (var conn = GetConnection())
                {
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = sql;

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                yield return new Stock(reader.GetInt32(0), reader.GetString(1));
                        }
                    }
                }
            }
            finally
            {
                StockManager.Message = sMessage;
            }
        }

        //This method checks whether stock exists in the database, and returns True or False
        public static bool IsStockExists(string _stockname)
        {
            bool Ok = false;
            var sql = string.Format("SELECT * FROM STOCKTABLE WHERE STOCKNAME='{0}';", _stockname);

            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = sql;

                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                Ok = true;
                        }
                    }
                }
            }
            finally
            {
                StockManager.Message = sMessage;
            }
            return Ok;
        }

        //This method inserts stock in the stock table
        public static bool SaveStock(string _stockname)
        {
            try
            {
                bool Ok = IsStockExists(_stockname.Trim().ToUpper());
                if (Ok)
                {
                    sMessage = string.Format("Stock Script '{0}' is already added.", _stockname);
                    return false;
                }
                using (var conn = GetConnection())
                {
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {

                        try
                        {
                            // Do an insert
                            cmd.CommandText = "INSERT INTO STOCKTABLE (StockName) VALUES (@StockName);";
                            cmd.Parameters.AddWithValue("@StockName", _stockname.ToUpper());
                            cmd.ExecuteNonQuery();

                            sMessage = string.Format("Stock Script '{0}' is added successfully.", _stockname.ToUpper());
                            return true;
                        }
                        catch (SqliteException ex)
                        {
                            sMessage = ex.Message;
                            return false;
                        }
                    }
                }
            }
            finally
            {
                StockManager.Message = sMessage;
            }
        }

        //This method deletes all the stocks from the stock table
        public static bool DeleteAllStocks()
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();

                    using (var cmd = conn.CreateCommand())
                    {

                        try
                        {
                            // Do an insert
                            cmd.CommandText = "DELETE FROM STOCKTABLE;";
                            cmd.ExecuteNonQuery();

                            sMessage = "All Stocks are deleted successfully...\nTo view the stocks in Market Watch, you need to add your custom stock";
                            return true;
                        }
                        catch (SqliteException ex)
                        {
                            sMessage = ex.Message;
                            return false;
                        }
                    }
                }
            }
            finally
            {
                StockManager.Message = sMessage;
            }
        }
    }
}